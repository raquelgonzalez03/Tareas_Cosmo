---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is. 
If you just want help, see the CosmoCoffee [help forum](https://cosmocoffee.info/viewforum.php?f=11) and [help assistant](https://cosmocoffee.info/help_assist.php).

**To Reproduce**
Steps to reproduce  (and platform if relevant). e.g. a complete python notebook.
