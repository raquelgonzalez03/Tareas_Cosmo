---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**Describe the additional feature that you'd like**
If you just want help, see the CosmoCoffee [help forum](https://cosmocoffee.info/viewforum.php?f=11) and [help assistant](https://cosmocoffee.info/help_assist.php).
