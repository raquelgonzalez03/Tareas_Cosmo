Source windows functions
==================================

.. autoclass:: camb.sources.SourceWindow
   :members:

.. autoclass:: camb.sources.GaussianSourceWindow
   :show-inheritance:
   :members:

.. autoclass:: camb.sources.SplinedSourceWindow
   :show-inheritance:
   :members:
