Reionization models
==================================

.. autoclass:: camb.reionization.ReionizationModel
   :members:

.. autoclass:: camb.reionization.BaseTauWithHeReionization
   :show-inheritance:
   :members:

.. autoclass:: camb.reionization.TanhReionization
   :show-inheritance:
   :members:

.. autoclass:: camb.reionization.ExpReionization
   :show-inheritance:
   :members:
